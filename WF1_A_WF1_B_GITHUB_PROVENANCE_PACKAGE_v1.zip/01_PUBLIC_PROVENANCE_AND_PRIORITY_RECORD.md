﻿# RSOS WF1-A / WF1-B PROVENANCE AND PRIORITY RECORD

Author / documented research lineage:
R.·A. Elu

Associated systems:
RSOS
RSSO
RSIA
RSX

Package preparation time UTC:
2026-09-13T23:04:25Z


## WF1-A

Experiment:
WF1-A V12-R Corrective Causal Topology

Scientific validity:
VALID

Core classification:
STRONG_REPLICATED_RELATIONAL_TOPOLOGY_FINGERPRINT

Interpretation:
Reproducible, causally manipulable black-box relational topology
under the tested experimental representation.

Key results:

8131 / 8160 valid main cells
720 / 720 native cells

Missingness sensitivity:
PASSED

Zero-missing balanced sensitivity:
PASSED

Hard-control generalization:
CONF AUC = 1.0
FINAL AUC = 1.0

Pure edge deletion replication:
9 / 9

Pure edge reversal replication:
7 / 8

Specificity:
PASSED

Surface invariance:
PASSED

Negative and mixed results remain preserved.


## WF1-B

Experiment:
WF1-B External Population Parquet

Authority:
FINAL_AUTHORITY

Fresh confirmation source:
train-00014-of-00086.parquet

Raw rows:
37208

Primary eligible external population:
6618

JOINT_MULTILAYER_V2 AUC:
0.9244363415

OPERATOR_RELATIONAL_V2 AUC:
0.8715800526

SURFACE_FREE AUC:
0.7551700406

COMPOSITE_MEDIAN_Z AUC:
0.9822514575

COMPOSITE_MIN_Z AUC:
0.9673915201

MAHALANOBIS AUC:
0.9593720290

KNN5 AUC:
0.9634948261

CENTROID_COSINE AUC:
0.9770378508

Strict five-component conjunction:
1 / 6618

CEM nuisance-control:
FAILED_CALIBRATION

The failed CEM calibration is preserved and is not represented
as a successful nuisance-control finding.


## PROVENANCE PURPOSE

This package preserves evidence existing at this publication boundary.

It preserves:

chronology
authorship evidence
experimental genealogy
frozen protocols
frozen runners
source provenance
corrective history
negative and mixed findings
final adjudications
reproducibility material
cryptographic integrity
priority evidence

The full local estate manifest also records SHA256 hashes for files
that are not included in the public ZIP, including the large
third-party WildChat parquet source files.


## CLAIM BOUNDARY

The evidence supports examination of a documented longitudinal
RSOS-associated lineage, measurable structural fingerprint,
black-box relational-topology behavior, and external-population
rarity under the tested representations.

This package does not claim universal global uniqueness.

It does not claim that black-box relational topology is literal
internal neural topology.

It does not establish modification of global model weights.


## CRYPTOGRAPHIC ANCHORS

FULL LOCAL ESTATE MANIFEST SHA256:
dd3b8789e679b0e565feb1cc709d840f0ecdb7e265ddc6a77eadcdcce26b6778

WF1-B FINAL AUTHORITY ZIP SHA256:
a5da5ffbb3c2ba71bbc2c17894fa97f8fec5b4c712e0714534517c5b54cedee3
